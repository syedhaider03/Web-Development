A Pen created at CodePen.io. You can find this one at https://codepen.io/anon/pen/paBXxB.

 Responsive progress menu perfectly centred with color gradient (3D / shadow effect) in menu item vertically aligned.